document.addEventListener("DOMContentLoaded", function () {});

function customButton(buttonText, className) {
  return `<button type="button" class="${className}">${buttonText}</button>`;
}

function allNum() {
  const arrc = Array.from(Array(10).keys()).concat([".", "="]);
  const buttons = document.getElementById("buttons");
  for (let i = 0; i < arrc.length; i++) {
    buttons.insertAdjacentHTML(
      "beforeend",
      customButton(arrc[i], "numButtonStyle")
    );
  }
}
function symbols() {
  const arr = ["+", "-", "*", "/"];
  const symbols = document.getElementById("symBtn");
  for (let i = 0; i < arr.length; i++) {
    symbols.insertAdjacentHTML(
      "beforeend",
      customButton(arr[i], "symButtonStyle")
    );
  }
}
function main() {
  allNum();
  symbols();
  const elements = document.querySelectorAll(".numButtonStyle");
  const symb = document.querySelectorAll(".symButtonStyle");
  let btnsArr = Array.from(elements);
  let sArr = Array.from(symb);

  btnsArr.forEach((element) => {
    element.addEventListener("click", (event) => {
      //
      document.getElementById("display-text").innerHTML +=
        event.target.innerHTML;
    });
  });

  sArr.forEach((symbs) => {
    symbs.addEventListener("click", (e) => {
      document.getElementById("display-text").innerHTML += e.target.innerHTML;
    });
  });
  operatorSym("+", 2, 3);
}

function operatorSym(operator, a, b) {
  if (operator === "+") {
    return a + b;
  } else if (operator === "-") {
    return a - b;
  } else if (operator === "*") {
    return a * b;
  } else if (operator === "/") {
    return a / b;
  } else {
    alert("please enter a valid number");
  }
}
function result(e) {
  e.target.addEventListener("click", function () {
    let results = document.getElementById("display-text");
    results.innerHTML = eval(results.innerHTML);
  });
}

let clearButton = document.getElementById("clear");
clearButton.addEventListener("click", clearAll());
function clearAll() {
  document.getElementById("display-text").value = "";
}
